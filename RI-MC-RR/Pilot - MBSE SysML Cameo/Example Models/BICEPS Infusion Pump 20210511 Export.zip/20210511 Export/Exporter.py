import sys
import os
from com.nomagic.magicdraw.core import Application
from com.nomagic.uml2.ext.jmi.helpers import StereotypesHelper
from com.nomagic.magicdraw.core import Project
from com.nomagic.magicdraw.uml import Finder
from com.nomagic.magicdraw.core.project import ProjectsManager

#global variables
handleCnt=0
mdsHandle=""
defaultLang="en-US"
privateCodeSemanticsOid="urn:oid:TBD"

#default values
defaultSafetyClassification="MedA"
defaultAsysSelfcheckPeriod="PT10S"
defaultAcKind="Phy"
defaultAcPrio="Hi"
defaultMaxTimeToFinish="PT2S"
defaultRetriggerable="false"
defaultAccessLevel="CSUsr"
defaultClockResolution="PT0.001S"
defaultMetricCategory="Msrmt" 
defaultMetricAvailability="Cont"
defaultMetricResolution="1"


#boilerplate
xml_boilerplate_start = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><msg:GetMdibResponse xmlns:ece=\"urn:oid:1.3.6.1.4.1.3592.2.23.5.1\" xmlns:ext=\"http://standards.ieee.org/downloads/11073/11073-10207-2017/extension\" xmlns:fn=\"http://www.w3.org/2005/xpath-functions\" xmlns:fo=\"http://www.w3.org/1999/XSL/Format\" xmlns:msg=\"http://standards.ieee.org/downloads/11073/11073-10207-2017/message\" xmlns:pm=\"http://standards.ieee.org/downloads/11073/11073-10207-2017/participant\" xmlns:xs=\"http://www.w3.org/2001/XMLSchema\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:schemaLocation=\"http://standards.ieee.org/downloads/11073/11073-10207-2017/message BICEPS_MessageModel.xsd\" SequenceId=\"urn:oid:1\"><msg:Mdib SequenceId=\"urn:oid:1\"><pm:MdDescription>"
xml_boilerplate_end = "</pm:MdDescription></msg:Mdib></msg:GetMdibResponse>"

xmlTypeElementName="Type"
xmlUnitElementName="Unit"
xmlBodySiteElementName="BodySite"

#root anchor
mdsRootInstanceQN="Infusion Pumps::MdDescription::Syringe Infusion Pump"
modelRootInstanceQN="Infusion Pumps"

#biceps types qns
mdsClazzQn="General BICEPS::BICEPS::MdsDescriptor"
handleQn="General BICEPS::BICEPS::Abstract Descriptors::AbstractDescriptor::Handle"
descriptorTypeQn="General BICEPS::BICEPS::Abstract Descriptors::AbstractDescriptor::Type"
alertSystemQn="General BICEPS::BICEPS::Abstract Descriptors::AbstractComplexDeviceComponentDescriptor::AlertSystem"
scoQn="General BICEPS::BICEPS::Abstract Descriptors::AbstractComplexDeviceComponentDescriptor::Sco"
mdsMetaDataQn="General BICEPS::BICEPS::MdsDescriptor::MetaData"
mdsSystemContextQn="General BICEPS::BICEPS::MdsDescriptor::SystemContext"
mdsClockQn="General BICEPS::BICEPS::MdsDescriptor::Clock"
mdsVmdQn="General BICEPS::BICEPS::MdsDescriptor::VMD"
vmdTypeQn="General BICEPS::BICEPS::VmdDescriptor"
vmdChannelQn="General BICEPS::BICEPS::VmdDescriptor::Channel"
channelTypeQn="General BICEPS::BICEPS::ChannelDescriptor"
metricChannelQn="General BICEPS::BICEPS::ChannelDescriptor::Metric"
metricUnitQn="General BICEPS::BICEPS::Abstract Descriptors::AbstractMetricDescriptor::Unit"
metricCategoryQn="General BICEPS::BICEPS::Abstract Descriptors::AbstractMetricDescriptor::MetricCategory"
metricAvailabilityQn="General BICEPS::BICEPS::Abstract Descriptors::AbstractMetricDescriptor::MetricAvailability"
determinationPeriodQn="General BICEPS::BICEPS::Abstract Descriptors::AbstractMetricDescriptor::DeterminationPeriod"
lifeTimePeriodQn="General BICEPS::BICEPS::Abstract Descriptors::AbstractMetricDescriptor::LifeTimePeriod"
nummetricResolutionQn="General BICEPS::BICEPS::Metrics::NumericMetricDescriptor::Resolution"
rtResolutionQn="General BICEPS::BICEPS::Metrics::NumericMetricDescriptor::Resolution"
metricAllowedValueQn="General BICEPS::BICEPS::Metrics::EnumStringMetricDescriptor::AllowedValue"
derivationMethodQn="General BICEPS::BICEPS::Abstract Descriptors::AbstractMetricDescriptor::DerivationMethod"
metricRelationQn="General BICEPS::BICEPS::Abstract Descriptors::AbstractMetricDescriptor::Relation"
metricBodySiteQn="General BICEPS::BICEPS::Abstract Descriptors::AbstractMetricDescriptor::BodySite"
abstractMetricTypeQn="General BICEPS::BICEPS::Abstract Descriptors::AbstractMetricDescriptor"
patCtxtQn="General BICEPS::BICEPS::Context::SystemContextDescriptor::PatientContext"
locCtxtQn="General BICEPS::BICEPS::Context::SystemContextDescriptor::LocationContext"
ensCtxtQn="General BICEPS::BICEPS::Context::SystemContextDescriptor::EnsembleContext"
allowedValueTypeQn="General BICEPS::BICEPS::Base Types::AllowedValue"
avValueQn="General BICEPS::BICEPS::Base Types::AllowedValue::Value"
codedValueTypeQn="General BICEPS::BICEPS::Base Types::CodedValue"
cvSymbolicCodeNameQn="General BICEPS::BICEPS::Base Types::CodedValue::SymbolicCodeName"
cvCodeQn="General BICEPS::BICEPS::Base Types::CodedValue::Code"
cvConceptDescQn="General BICEPS::BICEPS::Base Types::CodedValue::ConceptDescription"
cdTextQN="General BICEPS::BICEPS::Base Types::LocalizedText::"
scPeriodQn="General BICEPS::BICEPS::Alerts::AlertSystemDescriptor::selfCheckPeriod"
alertSystemConditionQn="General BICEPS::BICEPS::Alerts::AlertSystemDescriptor::alertCondition"
alertSystemSignalQn="General BICEPS::BICEPS::Alerts::AlertSystemDescriptor::alertSignal"
scoOperationsQn="General BICEPS::BICEPS::Control::ScoDescriptor::operation"
acKindQn="General BICEPS::BICEPS::Alerts::AlertConditionDescriptor::Kind"
acSourceQn="General BICEPS::BICEPS::Alerts::AlertConditionDescriptor::Source"
acPriorityQn="General BICEPS::BICEPS::Alerts::AlertConditionDescriptor::Priority"
safetyClassQn="General BICEPS::BICEPS::Abstract Descriptors::AbstractDescriptor::SafetyClassification"
operationTargetQn="General BICEPS::BICEPS::Abstract Descriptors::AbstractOperationDescriptor::OperationTarget"
maxTimeToFinishQn="General BICEPS::BICEPS::Abstract Descriptors::AbstractOperationDescriptor::MaxTimeToFinish"
retriggerableQn="General BICEPS::BICEPS::Abstract Descriptors::AbstractOperationDescriptor::Retriggerable"
accessLevelQn="General BICEPS::BICEPS::Abstract Descriptors::AbstractOperationDescriptor::AccessLevel"
timeProtocolQn="General BICEPS::BICEPS::ClockDescriptor::TimeProtocol"
clockResQn="General BICEPS::BICEPS::ClockDescriptor::Resolution"



def getXsiType(valInstance):
    retVal="NONE"
    classifiers=valInstance.getClassifier()
    clazz=classifiers[0]
    xsiTypeMap={
        "General BICEPS::BICEPS::Control::ActivateOperationDescriptor":"pm:ActivateOperationDescriptor",
        "General BICEPS::BICEPS::Control::SetAlertStateOperationDescriptor":"pm:SetAlertStateOperationDescriptor",
        "General BICEPS::BICEPS::Control::SetComponentStateOperationDescriptor":"pm:SetComponentStateOperationDescriptor",
        "General BICEPS::BICEPS::Control::SetContextStateOperationDescriptor":"pm:SetContextStateOperationDescriptor",
        "General BICEPS::BICEPS::Control::SetMetricStateOperationDescriptor":"pm:SetMetricStateOperationDescriptor",
        "General BICEPS::BICEPS::Control::SetStringOperationDescriptor":"pm:SetStringOperationDescriptor",
        "General BICEPS::BICEPS::Control::SetValueOperationDescriptor":"pm:SetValueOperationDescriptor",
        "General BICEPS::BICEPS::Metrics::DistributionSampleArrayMetricDescriptor":"pm:DistributionSampleArrayMetricDescriptor",
        "General BICEPS::BICEPS::Metrics::EnumStringMetricDescriptor":"pm:EnumStringMetricDescriptor",
        "General BICEPS::BICEPS::Metrics::NumericMetricDescriptor":"pm:NumericMetricDescriptor",
        "General BICEPS::BICEPS::Metrics::RealTimeSampleArrayMetricDescriptor":"pm:RealTimeSampleArrayMetricDescriptor",
        "General BICEPS::BICEPS::Metrics::StringMetricDescriptor":"pm:StringMetricDescriptor"
    }
    retVal=xsiTypeMap.get(clazz.getQualifiedName(),"NONE")
    return retVal


def isBicepsType(instanceElement, bicepsType):
    retVal=False
    ieClazz= instanceElement.getClassifier()
    for clazz in ieClazz:
       if (clazz.getQualifiedName()==bicepsType):
           retVal=True
           break
    return retVal

def extractAttributeEnumVal(aSlot):
    retVal="NONE"
    if (aSlot.hasValue()):
        slotKey=aSlot.getValue()[0]
        if slotKey.getHumanType()=="Instance Value":
            slotInstance=slotKey.getInstance()
            retVal=slotInstance.getName()
        else:
            Application.getInstance().getGUILog().log("extractAttributeEnumVal Failed "+str(slotKey.getHumanType()))
    return retVal

def extractAttributeHandleRefVal(aSlot):
    retVal="NONE"
    if (aSlot.hasValue()):
        slotKey=aSlot.getValue()[0]
        Application.getInstance().getGUILog().log("extracting AttributeHandleRef "+str(aSlot)+" "+str(slotKey.getHumanType()))
        if slotKey.getHumanType()=="Instance Value":
            slotInstance=slotKey.getInstance()
            iSlots=slotInstance.getSlot()
            handleDefined=False             
            for iSlot in iSlots:
                Application.getInstance().getGUILog().log("extracting AttributeHandleRef slot defininf feature"+str(iSlot.getDefiningFeature().getQualifiedName()))
                if (iSlot.getDefiningFeature().getQualifiedName()==handleQn):
                    handleDefined=True
                    return extractAttributeVal(iSlot)
            
            if not(handleDefined):
                Application.getInstance().getGUILog().log("Handle not defined for Referenz"+str(slotKey.getHumanType()))
        else:
            Application.getInstance().getGUILog().log("extracting AttributeHandleRef Failed "+str(slotKey.getHumanType()))
    return retVal

def extractAttributeVal(aSlot):
    retVal="NONE"
    if (aSlot.hasValue()):
        slotKey=aSlot.getValue()[0]
        if slotKey.getHumanType()=="Literal String":
            retVal=slotKey.getValue()
        elif slotKey.getHumanType()=="Literal Boolean":
            retVal=str(slotKey.isValue()).lower()
        else:
            Application.getInstance().getGUILog().log("extractAttributeVal Failed "+str(slotKey.getHumanType()))
    return retVal

def createHandle():
    global handleCnt
    handleCnt+=1
    handle=str(handleCnt)
    return handle

def createMdsProductSpec(mdibFile):
    mdsProdSpecXml="<pm:ProductionSpecification><pm:SpecType Code=\"68543\"><pm:ConceptDescription Lang=\""+defaultLang+"\">Private Coding Semantics</pm:ConceptDescription></pm:SpecType><pm:ProductionSpec>"+privateCodeSemanticsOid+"</pm:ProductionSpec></pm:ProductionSpecification>"
    mdibFile.write(mdsProdSpecXml)

def createAlertSignals(alertSignalSlot, mdibFile):
    #TODO Implement Alert Signal Handling 
    Application.getInstance().getGUILog().log("Alert Signal handling not implemented")
    global mdsHandle
    return


def createAlertConditions(alertConditionSlot, mdibFile):
    global mdsHandle
    acValues=alertConditionSlot.getValue()
    for acValue in acValues:
        Application.getInstance().getGUILog().log("Create AcValue "+str(acValue))
        if acValue.getHumanType()=="Instance Value":
            acKind=defaultAcKind
            acPrio=defaultAcPrio
            acHandle=createHandle()
            acSource=mdsHandle
            safetyClass=defaultSafetyClassification

            acValueInstance=acValue.getInstance()
            acSlots=acValueInstance.getSlot()
            typeSlot=None
            acKindSlot=None
            acPrioritySlot=None
            acSourceSlot=None
            acHandleslot=None
            safetyClassSlot=None
            for acSlot in acSlots:
                Application.getInstance().getGUILog().log("........Create AcSlots "+str(acSlot.getDefiningFeature().getQualifiedName()))
                if (acSlot.getDefiningFeature().getQualifiedName()==descriptorTypeQn):
                    typeSlot=acSlot
                if (acSlot.getDefiningFeature().getQualifiedName()==acKindQn):
                    acKindSlot=acSlot
                if (acSlot.getDefiningFeature().getQualifiedName()==acSourceQn):
                    acSourceSlot=acSlot
                if (acSlot.getDefiningFeature().getQualifiedName()==acPriorityQn):
                    acPrioritySlot=acSlot
                if (acSlot.getDefiningFeature().getQualifiedName()==handleQn):
                    acHandleslot=acSlot
                if (acSlot.getDefiningFeature().getQualifiedName()==safetyClassQn):
                    safetyClassSlot=acSlot

            if not(acHandleslot is None):
                acHandle=extractAttributeVal(acHandleslot)
            if not(safetyClassSlot is None):
                safetyClass=extractAttributeEnumVal(safetyClassSlot)
            if not(acKindSlot is None):
                acKind=extractAttributeEnumVal(acKindSlot)
            if not(acSourceSlot is None):
                acSource=extractAttributeHandleRefVal(acSourceSlot)
            if not(acPrioritySlot is None):
                acPrio=extractAttributeEnumVal(acPrioritySlot)

            acXmlStart="<pm:AlertCondition Handle=\""+acHandle+"\" SafetyClassification=\""+safetyClass+"\" Kind=\""+acKind+"\" Priority=\""+acPrio+"\">"                         
            acXmlEnd="</pm:AlertCondition>"

            acSource="<pm:Source>"+acSource+"</pm:Source>"
            Application.getInstance().getGUILog().log("........Writing AC "+str(acXmlStart))
            mdibFile.write(acXmlStart)
            if not(typeSlot is None): 
                createCodedValue(typeSlot,xmlTypeElementName,mdibFile)
            mdibFile.write(acSource)
            mdibFile.write(acXmlEnd)


def createCodedValue(slot, elemName, mdibFile):
    defFeat=slot.getDefiningFeature()
    if (defFeat.getType().getQualifiedName()==codedValueTypeQn):
                Application.getInstance().getGUILog().log("Create Type "+defFeat.getType().getQualifiedName()+" with Name "+elemName)
                if (slot.hasValue()):
                    slotValues=slot.getValue()
                    for value in slotValues:
                        #value=slot.getValue()[0]
                        valueInstance=value.getInstance()
                        code="-1"
                        symbolicCodeName=valueInstance.getName()
                        locText=symbolicCodeName
                        cvSlots=valueInstance.getSlot()
                        for cvSlot in cvSlots:
                            Application.getInstance().getGUILog().log("Create "+str(cvSlot.getDefiningFeature().getQualifiedName()))
                            if (cvSlot.getDefiningFeature().getQualifiedName()==cvCodeQn):
                                slotKey=cvSlot.getValue()[0]
                                if slotKey.getHumanType()=="Literal String":
                                    code=slotKey.getValue()
                            if (cvSlot.getDefiningFeature().getQualifiedName()==cvSymbolicCodeNameQn):
                                slotKey=cvSlot.getValue()[0]
                                if slotKey.getHumanType()=="Literal String":
                                    symbolicCodeName=slotKey.getValue()
                            if (cvSlot.getDefiningFeature().getQualifiedName()==cvConceptDescQn):
                                slotKey=cvSlot.getValue()[0]
                                Application.getInstance().getGUILog().log(slotKey.getHumanType())
                                if slotKey.getHumanType()=="Instance Value":
                                    cdValueInstance=slotKey.getInstance()
                                    cdSlots=cdValueInstance.getSlot()
                                    for cdSlot in cdSlots:
                                        if (cdSlot.getDefiningFeature().getQualifiedName()==cdTextQN):
                                            cdSlotKey=cdSlot.getValue()[0]
                                            if cdSlotKey.getHumanType()=="Literal String":
                                                locText=cdSlotKey.getValue()

                        typeXml="<pm:"+elemName+" Code=\""+code+"\" SymbolicCodeName=\""+symbolicCodeName+"\"><pm:ConceptDescription Lang=\""+defaultLang+"\">"+locText+"</pm:ConceptDescription></pm:"+elemName+">"
                        mdibFile.write(typeXml)

def createAlertSystem(alertSystemSlot, mdibFile):
    safetyClass=defaultSafetyClassification
    asysSelfcheckPeriod=defaultAsysSelfcheckPeriod
    asysHandle=createHandle()
    handleSlot=None
    typeSlot=None
    scPeriodSlot=None
    alertConditionSlot=None
    alertSignalSlot=None
    value=alertSystemSlot.getValue()[0]
    valueInstance=value.getInstance()
    slots=valueInstance.getSlot()
    for s in slots:
        defFeat=s.getDefiningFeature()
        Application.getInstance().getGUILog().log("Asys def Feat "+defFeat.getQualifiedName())
        if (defFeat.getQualifiedName()==descriptorTypeQn):
            typeSlot=s
        if (defFeat.getQualifiedName()==handleQn):
            handleSlot=s
        if (defFeat.getQualifiedName()==scPeriodQn):
            scPeriodSlot=s
        if (defFeat.getQualifiedName()==alertSystemConditionQn):
            alertConditionSlot=s
        if (defFeat.getQualifiedName()==alertSystemSignalQn):
            alertSignalSlot=s
        

    if not(handleSlot is None):
        asysHandle=extractAttributeVal(handleSlot)

    if not(scPeriodSlot is None):
        asysSelfcheckPeriod=extractAttributeVal(scPeriodSlot)

    alertSystemXmlStart="<pm:AlertSystem SafetyClassification=\""+safetyClass+"\" Handle=\""+asysHandle+"\" SelfCheckPeriod=\""+asysSelfcheckPeriod+"\">"
    alertSystemXmlEnd="</pm:AlertSystem>"

    mdibFile.write(alertSystemXmlStart)
    if not(alertConditionSlot is None):
        createAlertConditions(alertConditionSlot, mdibFile)
    if not(alertSignalSlot is None):
        createAlertSignals(alertSignalSlot, mdibFile)
    mdibFile.write(alertSystemXmlEnd)

    return

def createOperation(operationsSlot, mdibFile):
    global mdsHandle
    opValues=operationsSlot.getValue()
    for opValue in opValues:
        Application.getInstance().getGUILog().log("Create OpValue "+str(opValue))
        if opValue.getHumanType()=="Instance Value":
            opHandle=createHandle()
            opTarget=mdsHandle
            safetyClass=defaultSafetyClassification
            maxTimeToFinish=defaultMaxTimeToFinish
            retriggerable=defaultRetriggerable
            accessLevel=defaultAccessLevel

            opValueInstance=opValue.getInstance()

            xsiType=None
            xsiType=getXsiType(opValueInstance)

            opSlots=opValueInstance.getSlot()

            typeSlot=None
            safetyClassSlot=None
            maxTimeToFinishSlot=None
            opTargetSlot=None
            opHandleSlot=None
            retriggerableSlot=None
            accessLevelSlot=None

            for opSlot in opSlots:
                Application.getInstance().getGUILog().log("........Create OpSlots "+str(opSlot.getDefiningFeature().getQualifiedName()))
                if (opSlot.getDefiningFeature().getQualifiedName()==descriptorTypeQn):
                    typeSlot=opSlot
                if (opSlot.getDefiningFeature().getQualifiedName()==safetyClassQn):
                    safetyClassSlot=opSlot
                if (opSlot.getDefiningFeature().getQualifiedName()==maxTimeToFinishQn):
                    maxTimeToFinishSlot=opSlot
                if (opSlot.getDefiningFeature().getQualifiedName()==operationTargetQn):
                    opTargetSlot=opSlot
                if (opSlot.getDefiningFeature().getQualifiedName()==retriggerableQn):
                    retriggerableSlot=opSlot
                if (opSlot.getDefiningFeature().getQualifiedName()==accessLevelQn):
                    accessLevelSlot=opSlot
                if (opSlot.getDefiningFeature().getQualifiedName()==handleQn):
                    opHandleSlot=opSlot

            if not(opHandleSlot is None):
                opHandle=extractAttributeVal(opHandleSlot)
            if not(safetyClassSlot is None):
                safetyClass=extractAttributeEnumVal(safetyClassSlot)
            if not(opTargetSlot is None):
                opTarget=extractAttributeHandleRefVal(opTargetSlot)
            if not(maxTimeToFinishSlot is None):
                maxTimeToFinish=extractAttributeVal(maxTimeToFinishSlot)
            if not(retriggerableSlot is None):
                retriggerable=extractAttributeVal(retriggerableSlot)
            if not(accessLevelSlot is None):
                accessLevel=extractAttributeEnumVal(accessLevelSlot)
        
            operationXmlStart="<pm:Operation SafetyClassification=\""+safetyClass+"\" Handle=\""+opHandle+"\" xsi:type=\""+xsiType+"\" OperationTarget=\""+opTarget+"\" MaxTimeToFinish=\""+maxTimeToFinish+"\" Retriggerable=\""+retriggerable+"\" AccessLevel=\""+accessLevel+"\">"
            operationXmlEnd="</pm:Operation>"

            mdibFile.write(operationXmlStart)
            if not(typeSlot is None): 
                createCodedValue(typeSlot,xmlTypeElementName,mdibFile)
            mdibFile.write(operationXmlEnd)

    return

def createSco(scoSlot, mdibFile):
    scoHandle=createHandle()
    handleSlot=None
    typeSlot=None
    operationsSlot=None
    safetyClassSlot=None
    safetyClass=defaultSafetyClassification
    value=scoSlot.getValue()[0]
    valueInstance=value.getInstance()
    slots=valueInstance.getSlot()
    for s in slots:
        defFeat=s.getDefiningFeature()
        Application.getInstance().getGUILog().log("Sco def Feat "+defFeat.getQualifiedName())
        if (defFeat.getQualifiedName()==descriptorTypeQn):
            typeSlot=s
        if (defFeat.getQualifiedName()==handleQn):
            handleSlot=s
        if (defFeat.getQualifiedName()==scoOperationsQn):
            operationsSlot=s
        if (defFeat.getQualifiedName()==safetyClassQn):
            safetyClassSlot=s


    if not(handleSlot is None):
        scoHandle=extractAttributeVal(handleSlot)
    if not(safetyClassSlot is None):
        safetyClass=extractAttributeEnumVal(safetyClassSlot)

    scoXmlStart="<pm:Sco SafetyClassification=\""+safetyClass+"\" Handle=\""+scoHandle+"\">"
    scoXmlEnd="</pm:Sco>"
    mdibFile.write(scoXmlStart)
    
    if not(operationsSlot is None):
        createOperation(operationsSlot, mdibFile)
    else:
        Application.getInstance().getGUILog().log("Sco operationsSlot is none")

    mdibFile.write(scoXmlEnd)
    return

def createMetaData(metaDataSlot, mdibFile):
    Application.getInstance().getGUILog().log("Metadata not implemented")
    return

def createTimeProtocol(timeProtocolSlot,mdibFile):
    createCodedValue(timeProtocolSlot,"TimeProtocol",mdibFile)

    return

def createClock(clockSlot, mdibFile):
    clockResolution=defaultClockResolution
    handle=createHandle()
    handleSlot=None
    typeSlot=None
    resolutionSlot=None
    timeProtocolSlot=None
    safetyClass=defaultSafetyClassification
    value=clockSlot.getValue()[0]
    valueInstance=value.getInstance()
    slots=valueInstance.getSlot()
    for s in slots:
        defFeat=s.getDefiningFeature()
        Application.getInstance().getGUILog().log("Clock def Feat "+defFeat.getQualifiedName())
        if (defFeat.getQualifiedName()==descriptorTypeQn):
            typeSlot=s
        if (defFeat.getQualifiedName()==handleQn):
            handleSlot=s
        if (defFeat.getQualifiedName()==clockResQn):
            clockResolution=s
        if (defFeat.getQualifiedName()==safetyClassQn):
            safetyClassSlot=s
        if (defFeat.getQualifiedName()==timeProtocolQn):
            timeProtocolSlot=s

    if not(handleSlot is None):
        handle=extractAttributeVal(handleSlot)
    if not(safetyClassSlot is None):
        safetyClass=extractAttributeEnumVal(safetyClassSlot)
    if not(resolutionSlot is None):
        clockResolution=extractAttributeVal(resolutionSlot)

    clockXmlStart="<pm:Clock Handle=\""+handle+"\" Resolution=\""+clockResolution+"\" SafetyClassification=\""+safetyClass+"\">"
    clockXmlEnd="</pm:Clock>"

    mdibFile.write(clockXmlStart)
    if not(typeSlot is None): 
        createCodedValue(typeSlot,xmlTypeElementName,mdibFile)
    if not(timeProtocolQn is None):
        createTimeProtocol(timeProtocolSlot,mdibFile)

    mdibFile.write(clockXmlEnd)

def createContextElement(ctxtSlot, mdibFile, ctxtElementName):
    ctxtHandle=createHandle()
    safetyClass=defaultSafetyClassification

    handleSlot=None
    safetyClassSlot=None
    typeSlot=None

    value=ctxtSlot.getValue()[0]
    valueInstance=value.getInstance()
    slots=valueInstance.getSlot()

    for ctxtSlot in slots:
        Application.getInstance().getGUILog().log("........Create CtxtSLots "+str(ctxtSlot.getDefiningFeature().getQualifiedName()))
        if (ctxtSlot.getDefiningFeature().getQualifiedName()==descriptorTypeQn):
            typeSlot=ctxtSlot
        if (ctxtSlot.getDefiningFeature().getQualifiedName()==safetyClassQn):
            safetyClassSlot=ctxtSlot
        if (ctxtSlot.getDefiningFeature().getQualifiedName()==handleQn):
            handleSlot=ctxtSlot

    if not(handleSlot is None):
        ctxtHandle=extractAttributeVal(handleSlot)
    if not(safetyClassSlot is None):
        safetyClass=extractAttributeEnumVal(safetyClassSlot)

    ctxtXmlStart="<pm:"+ctxtElementName+" SafetyClassification=\""+safetyClass+"\" Handle=\""+ctxtHandle+"\">"
    ctxtXmlEnd="</pm:"+ctxtElementName+">"

    mdibFile.write(ctxtXmlStart)
    if not(typeSlot is None): 
        createCodedValue(typeSlot,xmlTypeElementName,mdibFile)
    mdibFile.write(ctxtXmlEnd)

def createSystemContext(systemContextSlot, mdibFile):
    sysCtxtHandle=createHandle()
    safetyClass=defaultSafetyClassification

    handleSlot=None
    typeSlot=None
    patCtxtSlot=None
    locCtxtSlot=None
    ensCtxtSlot=None
    opCtxtSlot=None
    wfCtxtSlot=None
    meansCtxtSlot=None

    value=systemContextSlot.getValue()[0]
    valueInstance=value.getInstance()
    slots=valueInstance.getSlot()
    for s in slots:
        defFeat=s.getDefiningFeature()
        Application.getInstance().getGUILog().log("Operation def Feat "+defFeat.getQualifiedName())
        if (defFeat.getQualifiedName()==descriptorTypeQn):
            typeSlot=s
        if (defFeat.getQualifiedName()==handleQn):
            handleSlot=s
        if (defFeat.getQualifiedName()==patCtxtQn):
            patCtxtSlot=s
        if (defFeat.getQualifiedName()==locCtxtQn):
            locCtxtSlot=s
        if (defFeat.getQualifiedName()==ensCtxtQn):
            ensCtxtSlot=s


    if not(handleSlot is None):
        sysCtxtHandle=extractAttributeVal(handleSlot)

    sysCtxtXmlStart="<pm:SystemContext SafetyClassification=\""+safetyClass+"\" Handle=\""+sysCtxtHandle+"\">"
    sysCtxtXmlEnd="</pm:SystemContext>"
    mdibFile.write(sysCtxtXmlStart)
    if not(typeSlot is None): 
        createCodedValue(typeSlot,xmlTypeElementName,mdibFile)

    if not(patCtxtSlot is None):
        createContextElement(patCtxtSlot, mdibFile, "PatientContext")
    else:
        Application.getInstance().getGUILog().log("SystemContext patContext is none")

    if not(locCtxtSlot is None):
        createContextElement(locCtxtSlot, mdibFile, "LocationContext")
    else:
        Application.getInstance().getGUILog().log("SystemContext locCtxt is none")
    
    if not(ensCtxtSlot is None):
        createContextElement(ensCtxtSlot, mdibFile, "EnsembleContext")
    else:
        Application.getInstance().getGUILog().log("SystemContext ensCtxt is none")

    #TODO opContext, wfContext, meansContext

    mdibFile.write(sysCtxtXmlEnd)
    return

def createMetricAllowedValue(metricAllowedValueSlot, mdibFile):
    defFeat=metricAllowedValueSlot.getDefiningFeature()
    if (defFeat.getType().getQualifiedName()==allowedValueTypeQn):
                Application.getInstance().getGUILog().log("Create AllowedValue "+defFeat.getType().getQualifiedName())
                if (metricAllowedValueSlot.hasValue()):
                    slotValues=metricAllowedValueSlot.getValue()
                    for value in slotValues:
                        #value=slot.getValue()[0]
                        valueInstance=value.getInstance()
                        value="-1"
                        cvSlots=valueInstance.getSlot()
                        for cvSlot in cvSlots:
                            Application.getInstance().getGUILog().log("Create "+str(cvSlot.getDefiningFeature().getQualifiedName()))
                            if (cvSlot.getDefiningFeature().getQualifiedName()==avValueQn):
                                slotKey=cvSlot.getValue()[0]
                                if slotKey.getHumanType()=="Literal String":
                                    value=slotKey.getValue()

                        allowedValueXmlStart="<pm:AllowedValue><pm:Value>"+value+"</pm:Value>"
                        allowedValueXmlEnd="</pm:AllowedValue>"
                        mdibFile.write(allowedValueXmlStart)
                        mdibFile.write(allowedValueXmlEnd)


    return

def createMetricRelation(metricRelationSlot,mdibFile):
    return

def createMetrics(metricsSlot,mdibFile):
    defFeat=metricsSlot.getDefiningFeature()
    Application.getInstance().getGUILog().log("Create Metrics "+defFeat.getType().getQualifiedName())
    if (defFeat.getType().getQualifiedName()==abstractMetricTypeQn):
        if (metricsSlot.hasValue()):
            metricValues=metricsSlot.getValue()
            for metricValue in metricValues:
                metricValueInstance=metricValue.getInstance()
                metricSlots=metricValueInstance.getSlot()

                handle=createHandle()
                safetyClass=defaultSafetyClassification
                metricCategory=defaultMetricCategory
                metricAvailability=defaultMetricAvailability
                metricResolution=defaultMetricResolution

                xsiType=None
                xsiType=getXsiType(metricValueInstance)

                typeSlot=None
                handleSlot=None
                safetyClassSlot=None
                unitSlot=None
                determinationPeriodSlot=None
                lifeTimePeriodSlot=None
                metricResolutionSlot=None
                derivationMethodSlot=None
                metricRelationSlot=None
                metricAllowedValueSlot=None
                metricBodySiteSlot=None

                for s in metricSlots:
                    defFeat=s.getDefiningFeature()
                    Application.getInstance().getGUILog().log("Create Metric slots "+str(defFeat.getQualifiedName()))
                    if (defFeat.getQualifiedName()==descriptorTypeQn):
                        typeSlot=s
                    if (defFeat.getQualifiedName()==handleQn):
                        handleSlot=s
                    if (defFeat.getQualifiedName()==safetyClassQn):
                        safetyClassSlot=s
                    if (defFeat.getQualifiedName()==metricUnitQn):
                        unitSlot=s
                    if (defFeat.getQualifiedName()==metricCategoryQn):
                        metricCategorySlot=s
                    if (defFeat.getQualifiedName()==metricAvailabilityQn):
                        metricAvailabilitySlot=s
                    if (defFeat.getQualifiedName()==determinationPeriodQn):
                        determinationPeriodSlot=s
                    if (defFeat.getQualifiedName()==lifeTimePeriodQn):
                        lifeTimePeriodSlot=s
                    if (defFeat.getQualifiedName()==nummetricResolutionQn):
                        metricResolutionSlot=s
                    if (defFeat.getQualifiedName()==rtResolutionQn):
                        metricResolutionSlot=s
                    if (defFeat.getQualifiedName()==derivationMethodQn):
                        derivationMethodSlot=s
                    if (defFeat.getQualifiedName()==metricBodySiteQn):
                        metricBodySiteSlot=s
                    if (defFeat.getQualifiedName()==metricRelationQn):
                        metricRelationSlot=s
                    if (defFeat.getQualifiedName()==metricAllowedValueQn):
                        metricAllowedValueSlot=s


                if not(handleSlot is None):
                    handle=extractAttributeVal(handleSlot)
                if not(safetyClassSlot is None):
                    safetyClass=extractAttributeEnumVal(safetyClassSlot)

                #SafetyClassification="MedA" DeterminationPeriod="PT1S" LifeTimePeriod="PT1S" DerivationMethod="Auto"
                
                metricXmlStart="<pm:Metric xsi:type=\""+xsiType+"\" SafetyClassification=\""+safetyClass+"\" Handle=\""+handle+"\" MetricCategory=\""+metricCategory+"\" MetricAvailability=\""+metricAvailability+"\"" 
                metricXmlStartClosing=" >"
                metricXmlEnd="</pm:Metric>"

                mdibFile.write(metricXmlStart)
                if (xsiType=="pm:NumericMetricDescriptor" or xsiType=="pm:RealTimeSampleArrayMetricDescriptor" or xsiType=="pm:DistributionSampleArrayDescriptor"):
                    metricResolutionXml=" Resolution=\""+metricResolution+"\" "
                    mdibFile.write(metricResolutionXml)
                
                if not(determinationPeriodSlot is None): 
                    determinationPeriod=extractAttributeVal(determinationPeriodSlot)
                    metricDPXml=" DeterminationPeriod=\""+determinationPeriod+"\" "
                    mdibFile.write(metricDPXml)
                
                if not(lifeTimePeriodSlot is None): 
                    lifeTimePeriod=extractAttributeVal(lifeTimePeriodSlot)
                    metricLTPXml=" LifeTimePeriod=\""+lifeTimePeriod+"\" "
                    mdibFile.write(metricLTPXml)

                if not(derivationMethodSlot is None): 
                    derivationMethod=extractAttributeEnumVal(derivationMethodSlot)
                    metricDMXml=" DerivationMethod=\""+derivationMethod+"\" "
                    mdibFile.write(metricDMXml)

                mdibFile.write(metricXmlStartClosing)
                if not(typeSlot is None): 
                    createCodedValue(typeSlot,xmlTypeElementName,mdibFile)

                if not(unitSlot is None): 
                    createCodedValue(unitSlot,xmlUnitElementName,mdibFile)
                
                if not(metricBodySiteSlot is None): 
                    createCodedValue(metricBodySiteSlot,xmlBodySiteElementName,mdibFile)
                
                if not(metricRelationSlot is None): 
                    createMetricRelation(metricRelationSlot,mdibFile)
                
                if not(metricAllowedValueSlot is None):
                    createMetricAllowedValue(metricAllowedValueSlot, mdibFile)

                mdibFile.write(metricXmlEnd)
    
    return

def createChannels(channelSlot, mdibFile):
    defFeat=channelSlot.getDefiningFeature()
    Application.getInstance().getGUILog().log("Create Channel "+defFeat.getType().getQualifiedName())
    if (defFeat.getType().getQualifiedName()==channelTypeQn):
        if (channelSlot.hasValue()):
            channelValues=channelSlot.getValue()
            for channelValue in channelValues:
                #value=slot.getValue()[0]
                channelValueInstance=channelValue.getInstance()
                channelSlots=channelValueInstance.getSlot()

                handle=createHandle()
                safetyClass=defaultSafetyClassification

                typeSlot=None
                handleSlot=None
                metricSlots=None
                safetyClassSlot=None

                for s in channelSlots:
                    defFeat=s.getDefiningFeature()
                    Application.getInstance().getGUILog().log("Create Channel slots "+str(defFeat.getQualifiedName()))
                    if (defFeat.getQualifiedName()==descriptorTypeQn):
                        typeSlot=s
                    if (defFeat.getQualifiedName()==handleQn):
                        handleSlot=s
                    if (defFeat.getQualifiedName()==safetyClassQn):
                        safetyClassSlot=s
                    if (defFeat.getQualifiedName()==metricChannelQn):
                        metricSlots=s

                if not(handleSlot is None):
                    handle=extractAttributeVal(handleSlot)
                if not(safetyClassSlot is None):
                    safetyClass=extractAttributeEnumVal(safetyClassSlot)
                
                channelXmlStart="<pm:Channel SafetyClassification=\""+safetyClass+"\" Handle=\""+handle+"\">"
                channelXmlEnd="</pm:Channel>"

                mdibFile.write(channelXmlStart)
                if not(typeSlot is None): 
                    createCodedValue(typeSlot,xmlTypeElementName,mdibFile)

                if not(metricSlots is None):
                    createMetrics(metricSlots,mdibFile)

                mdibFile.write(channelXmlEnd)
    return

def createVMDs(vmdSlot, mdibFile):
    defFeat=vmdSlot.getDefiningFeature()
    Application.getInstance().getGUILog().log("Create VMD "+defFeat.getType().getQualifiedName())
    if (defFeat.getType().getQualifiedName()==vmdTypeQn):
                if (vmdSlot.hasValue()):
                    vmdValues=vmdSlot.getValue()
                    for vmdValue in vmdValues:
                        #value=slot.getValue()[0]
                        vmdValueInstance=vmdValue.getInstance()
                        vmdSlots=vmdValueInstance.getSlot()

                        handle=createHandle()
                        safetyClass=defaultSafetyClassification

                        typeSlot=None
                        handleSlot=None
                        channelSlot=None
                        safetyClassSlot=None

                        for s in vmdSlots:
                            defFeat=s.getDefiningFeature()
                            Application.getInstance().getGUILog().log("Create "+str(defFeat.getQualifiedName()))
                            if (defFeat.getQualifiedName()==descriptorTypeQn):
                                typeSlot=s
                            if (defFeat.getQualifiedName()==handleQn):
                                handleSlot=s
                            if (defFeat.getQualifiedName()==safetyClassQn):
                                safetyClassSlot=s
                            if (defFeat.getQualifiedName()==vmdChannelQn):
                                channelSlot=s

                        if not(handleSlot is None):
                            handle=extractAttributeVal(handleSlot)
                        if not(safetyClassSlot is None):
                            safetyClass=extractAttributeEnumVal(safetyClassSlot)
                        
                        vmdXmlStart="<pm:Vmd SafetyClassification=\""+safetyClass+"\" Handle=\""+handle+"\">"
                        vmdXmlEnd="</pm:Vmd>"

                        mdibFile.write(vmdXmlStart)
                        if not(typeSlot is None): 
                            createCodedValue(typeSlot,xmlTypeElementName,mdibFile)
                        #Create AlertSystem
                        #Create SCO

                        if not(channelSlot is None):
                            createChannels(channelSlot,mdibFile)

                        
                        mdibFile.write(vmdXmlEnd)

    return

def createMDS(ieMDS, mdibFile):
    global mdsHandle
    mdsHandle=createHandle()
    slots=ieMDS.getSlot()
    typeSlot=None
    alertSystemSlot=None
    scoSlot = None
    metaDataSlot=None
    systemContextSlot=None
    clockSlot=None
    vmdSlot=None
    handleSlot=None
    for s in slots:
        defFeat=s.getDefiningFeature()
        Application.getInstance().getGUILog().log("def Feat "+defFeat.getQualifiedName())
        if (defFeat.getQualifiedName()==descriptorTypeQn):
            typeSlot=s
        if (defFeat.getQualifiedName()==alertSystemQn):
            alertSystemSlot=s
        if (defFeat.getQualifiedName()==scoQn):
            scoSlot=s
        if (defFeat.getQualifiedName()==mdsMetaDataQn):
            metaDataSlot=s
        if (defFeat.getQualifiedName()==mdsSystemContextQn):
            systemContextSlot=s
        if (defFeat.getQualifiedName()==mdsClockQn):
            clockSlot=s
        if (defFeat.getQualifiedName()==mdsVmdQn):
            vmdSlot=s
        if (defFeat.getQualifiedName()==handleQn):
            handleSlot=s

    if not(handleSlot is None):
        mdsHandle=extractAttributeVal(handleSlot)

    safetyClass=defaultSafetyClassification
    mdsXmlStart="<pm:Mds Handle=\""+mdsHandle+"\" SafetyClassification=\""+safetyClass+"\">"
    mdsXmlEnd="</pm:Mds>"

    mdibFile.write(mdsXmlStart)
    createCodedValue(typeSlot,xmlTypeElementName,mdibFile)
    createMdsProductSpec(mdibFile)
    if not(alertSystemSlot is None):
        createAlertSystem(alertSystemSlot,mdibFile)
    
    if not(scoSlot is None):
        createSco(scoSlot,mdibFile)

    if not(metaDataSlot is None):
        createMetaData(metaDataSlot,mdibFile)
    
    if not(systemContextSlot is None):
        createSystemContext(systemContextSlot,mdibFile)
    
    if not(clockSlot is None):
        createClock(clockSlot,mdibFile)

    if not(vmdSlot is None):
        createVMDs(vmdSlot,mdibFile)

    mdibFile.write(mdsXmlEnd)




pMgr=Application.getInstance().getProjectsManager()
project=pMgr.getActiveProject()
primaryModel=project.getPrimaryModel()
Application.getInstance().getGUILog().log("Model: "+primaryModel.getName())
byNameFinder=Finder.byNameRecursively()
byQnFinder=Finder.byQualifiedName()


modelRootInstanceElem= byQnFinder.find(project,modelRootInstanceQN)

mdsRootInstanceElem= byQnFinder.find(project,mdsRootInstanceQN)

Application.getInstance().getGUILog().log("Model Root Elem:"+modelRootInstanceElem.getName())

mdsRootPackage=None
packages=modelRootInstanceElem.getNestedPackage()
for p in packages:
    if p.getName()=="MdDescription":
        mdsRootPackage=p
        break


mdibFile = open('C:\\Users\\stefan.schlichting\\OneDrive - UNITY AG\\Projekte\\Schweiz\\JHU-APL\\Infusion Pump\\ExportMdib.xml','w')
mdibFile.write(xml_boilerplate_start)
if not(mdsRootInstanceElem is None):
    Application.getInstance().getGUILog().log("Root Elem:"+mdsRootInstanceElem.getName())
    if (isBicepsType(mdsRootInstanceElem,mdsClazzQn)):
        createMDS(mdsRootInstanceElem, mdibFile)

else:
    Application.getInstance().getGUILog().log("Root Elem is None")

mdibFile.write(xml_boilerplate_end)
mdibFile.close()